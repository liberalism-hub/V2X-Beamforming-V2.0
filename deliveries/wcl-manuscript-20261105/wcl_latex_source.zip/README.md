# 中文修订稿：Astra实现与当前A—C证据对齐版

本目录保留原稿第II—IV节结构，交付系统模型、算法与数值结果的中文研究稿。作者、摘要、引言与最近工作比较没有被擅自补写。本文不是此前离散MCS模型，也不是原稿旧QMC/SAA实验的简单换图版。

## 编译

使用XeLaTeX，所需常规依赖为IEEEtran、ctex/xeCJK/Fandol、fontspec/TeX Gyre Termes、amsmath/amssymb/bm、graphicx、booktabs、tabularx、cite、hyperref。完整TeX Live或Overleaf中选择XeLaTeX即可。

在本目录执行：

    xelatex -no-shell-escape -halt-on-error -interaction=nonstopmode manuscript_revised.tex
    xelatex -no-shell-escape -halt-on-error -interaction=nonstopmode manuscript_revised.tex

本云环境最初缺少若干包，已在工作区局部准备依赖；环境记录见外层review/build_notes.md。交付包不包含较大的本地TeX依赖树。

## 图表再生成

安装NumPy、SciPy、Matplotlib后，在本目录执行：

    python generate_tables.py
    python plot_manuscript_figures.py

脚本默认读取data目录，主图使用11个固定纵向位置的预注册实验。表格和图件均来自现有冻结CSV，没有重跑仿真；主图C为节省版面只画TC/B，完整五方法C图放在supplementary_figures。

data_manifest.json用于核验输入数据未变。这里的CSV足以重建图表；本包未包含440万窗口的原始大样本NPZ，不是完整仿真断点缓存。完整蒙特卡洛复现应使用此前交付的Astra实验源码与固定协议。

## 重要口径

- 数据20/50/100ms之外另加2ms，H=20/50/100，步长1ms。
- 连续窗内固定速率，最低2bit/s/Hz；算法最大化可保证速率，goodput独立测试。
- 固定等权几何上下文不是实际交通分布，收益区间不包含重抽校准的学习波动。
- 统计风险与计算期限分开：本轮没有实现2ms在线端到端保证。
- 原稿旧7dBm/ST-Cal/道路行驶等结果尚缺配套材料核验，未与当前结果混合。

详细审稿分析与修改原因见外层review目录。
