"""Publication-sized A--C plots from frozen, precomputed eleven-context data."""
from pathlib import Path
import argparse
import csv
import hashlib
import json
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.ticker import ScalarFormatter
import numpy as np

HERE = Path(__file__).resolve().parent
COLORS = {"TC-WRAC": "#176b9c", "S-WRAC": "#8a62a8",
          "B-WRAC": "#d57d26", "Fixed-Full": "#697180", "Fixed-Wide": "#368a61"}
SHORT = {"TC-WRAC": "TC", "S-WRAC": "Sidak", "B-WRAC": "B",
         "Fixed-Full": "Full", "Fixed-Wide": "Wide"}
METHODS = list(COLORS)

def rows(path):
    with Path(path).open(encoding="utf-8-sig") as f:
        result = list(csv.DictReader(f))
    for r in result:
        for key, value in r.items():
            if value == "":
                r[key] = None
            elif value in ("True", "False"):
                r[key] = value == "True"
            else:
                try:
                    r[key] = float(value)
                except ValueError:
                    pass
    return result

def style():
    plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 8.5,
                         "axes.labelsize": 8.5, "axes.titlesize": 9,
                         "xtick.labelsize": 8.5, "ytick.labelsize": 8.5,
                         "legend.fontsize": 8.5, "axes.spines.top": False,
                         "axes.spines.right": False, "pdf.fonttype": 42,
                         "svg.fonttype": "none", "lines.linewidth": 1.25,
                         "lines.markersize": 3.5})

def save(fig, output, name):
    output.mkdir(parents=True, exist_ok=True)
    for suffix in ("pdf", "svg", "png"):
        fig.savefig(output / f"{name}.{suffix}", dpi=300)
    plt.close(fig)

def coverage(ax, data, xkey, categories, methods):
    for m in methods:
        sub = sorted([r for r in data if r["method"] == m], key=lambda r: r[xkey])
        x = np.arange(len(sub)) if categories else [r[xkey] for r in sub]
        y = 100 * np.array([r["coverage"] for r in sub])
        lower = 100 * np.array([r["coverage_ci_low"] for r in sub])
        upper = 100 * np.array([r["coverage_ci_high"] for r in sub])
        col = COLORS.get(m, "#666666")
        ax.errorbar(x, y, yerr=[y-lower, upper-y], color=col,
                    marker="x" if m == "S-WRAC" else "o", capsize=2,
                    ls="--" if m == "TC-no-remainder" else "-",
                    label=SHORT.get(m, m))
    ax.set_ylabel("Joint coverage (%)")
    ax.grid(axis="y", alpha=.22)

def plot_a(data, out):
    known = rows(data / "A/known_gaussian.csv")
    physical = rows(data / "A/state_space.csv")
    fig, ax = plt.subplots(2, 2, figsize=(7, 4.3))
    fig.subplots_adjust(left=.09, right=.985, bottom=.135, top=.88,
                        hspace=.64, wspace=.37)
    rhos = sorted(set(r["rho"] for r in known))
    Hs = sorted(set(r["H"] for r in physical))
    for m in ("TC-WRAC", "S-WRAC", "B-WRAC"):
        sub = sorted([r for r in known if r["method"] == m], key=lambda r:r["rho"])
        ax[0,0].plot(range(len(sub)), [r["q_ratio_to_B"] for r in sub],
                     "x-" if m == "S-WRAC" else "o-", color=COLORS[m], label=SHORT[m])
        sub = sorted([r for r in physical if r["method"] == m], key=lambda r:r["H"])
        ax[1,0].plot(range(len(sub)), [r["q_ratio_to_B"] for r in sub],
                     "x-" if m == "S-WRAC" else "o-", color=COLORS[m])
    coverage(ax[0,1], known, "rho", True, ["TC-WRAC","S-WRAC","B-WRAC"])
    coverage(ax[1,1], physical, "H", True, ["TC-WRAC","S-WRAC","B-WRAC","TC-no-remainder"])
    ax[0,1].axhline(99.3, color="black", ls=":", lw=1)
    ax[0,1].text(.04, .56, "Target: 99.3%", ha="left", va="center",
                 transform=ax[0,1].transAxes, fontsize=8.5)
    ax[1,1].axhline(99.1, color="black", ls=":", lw=1)
    ax[1,1].text(.98, 99.11, "99.1% target", ha="right", va="bottom",
                 transform=ax[1,1].get_yaxis_transform(), fontsize=8.5)
    ax[1,1].text(.06, .13, "No remainder (diagnostic)", color="#666666",
                 transform=ax[1,1].transAxes, fontsize=8.5)
    for a in ax[0]:
        a.set_xticks(range(len(rhos)), [f"{v:g}" for v in rhos])
        a.set_xlabel(r"AR(1) correlation $\rho$")
    for a in ax[1]:
        a.set_xticks(range(len(Hs)), [f"{v:g}" for v in Hs])
        a.set_xlabel("Data endpoints H (1 ms)")
    for a in (ax[0,0],ax[1,0]):
        a.set_ylabel(r"Quantile ratio $q/q_B$")
        a.grid(axis="y",alpha=.22)
    for a, title in zip(ax.flat, ["(a) Known Gaussian: quantiles", "(b) Known Gaussian: coverage",
                                  "(c) State model: quantiles", "(d) True-geometry coverage"]):
        a.set_title(title)
    handles, labels = ax[0,0].get_legend_handles_labels()
    fig.legend(handles, labels, loc="upper center", ncol=3, bbox_to_anchor=(.52,.995),
               frameon=False)
    fig.text(.09,.015,"Error bars: pointwise 95% Clopper--Pearson intervals.",fontsize=8.5)
    save(fig,out,"Fig_A_calibration")

def line_style(method, power):
    return dict(color=COLORS[method], ls="--" if power==10 else "-",
                marker="o" if power==10 else "s")

def baseline_risk(risk, feasible):
    keys = {r["case_id"] for r in feasible}
    return [r for r in risk if r["case_id"] in keys]

def plot_b(data, out):
    feasible = rows(data/"feasible_summary.csv")
    summary = rows(data/"B_summary.csv")
    risk = baseline_risk(rows(data/"risk_checks.csv"),feasible)
    fig,ax=plt.subplots(2,2,figsize=(7,4.4))
    fig.subplots_adjust(left=.09,right=.985,bottom=.14,top=.86,hspace=.62,wspace=.37)
    x=np.arange(5)
    for j,power in enumerate((10,20)):
        sub={r["method"]:r for r in summary if r["power_dbm"]==power}
        bars=ax[0,0].bar(x+(j-.5)*.36,[100*sub[m]["availability"] for m in METHODS],
                         width=.34,color=[COLORS[m] for m in METHODS],
                         hatch="//" if power==10 else None,
                         alpha=.65 if power==10 else 1)
    ax[0,0].set_xticks(x,[SHORT[m] for m in METHODS])
    ax[0,0].set_ylim(0,110)
    ax[0,0].set_ylabel("Feasible contexts (%)")
    for power in (10,20):
        for m in ("TC-WRAC","B-WRAC"):
            sub=sorted([r for r in feasible if r["power_dbm"]==power and r["method"]==m],
                       key=lambda r:r["y0_m"])
            ax[0,1].plot([r["y0_m"] for r in sub],[r["n_feasible"] for r in sub],
                         **line_style(m,power))
            sub=sorted([r for r in risk if r["power_dbm"]==power and r["method"]==m],
                       key=lambda r:r["y0_m"])
            ax[1,1].plot([r["y0_m"] for r in sub],
                         [100*r["risk_upper_family"] if r["served"] else np.nan for r in sub],
                         **line_style(m,power))
    same={}
    for m in ("TC-WRAC","B-WRAC"):
        a=sorted([r for r in feasible if r["power_dbm"]==10 and r["method"]==m],key=lambda r:r["y0_m"])
        b=sorted([r for r in feasible if r["power_dbm"]==20 and r["method"]==m],key=lambda r:r["y0_m"])
        ma=np.array([r["m_star"] for r in a])
        mb=np.array([r["m_star"] for r in b])
        assert np.array_equal(ma,mb), "Do not pool differing power-specific decisions"
        same[m]=ma.tolist()
        support=np.arange(65)
        ax[1,0].step(support,[np.mean(ma<=v) for v in support],where="post",
                     color=COLORS[m],label=SHORT[m])
    ax[1,0].set_xlim(0,64)
    ax[1,0].set_ylim(0,1.06)
    ax[1,0].set_ylabel("Empirical CDF")
    ax[1,0].set_xlabel(r"Selected aperture $m^\star$")
    ax[1,0].text(.02,.86,"Same decisions\nat both powers",transform=ax[1,0].transAxes,
                 fontsize=8.5)
    ax[1,0].legend(loc="lower right",frameon=False)
    ax[0,1].set_ylabel("Feasible candidates")
    ax[0,1].set_xlabel(r"Predicted $\hat y_0$ (m)")
    ax[1,1].set_ylabel("Outage upper bound (%)")
    ax[1,1].set_xlabel(r"Predicted $\hat y_0$ (m)")
    ax[1,1].axhline(1,color="black",ls=":",lw=1)
    ax[1,1].set_ylim(0,1.1)
    ax[1,1].text(.98,.99,"1% target",ha="right",va="top",transform=ax[1,1].transAxes,
                 fontsize=8.5)
    for a in (ax[0,1],ax[1,1]):
        a.set_xticks([-100,-50,0,50,100])
    for a,title in zip(ax.flat,["(a) Service feasibility","(b) Feasible-set size",
                                "(c) Selected-aperture distribution","(d) Conditional risk bounds"]):
        a.set_title(title)
        a.grid(axis="y",alpha=.22)
    handles=[Line2D([],[],**line_style(m,p),label=f"{SHORT[m]}, {p} dBm")
             for p in (10,20) for m in ("TC-WRAC","B-WRAC")]
    fig.legend(handles=handles,loc="upper center",bbox_to_anchor=(.52,.995),ncol=4,
               handlelength=1.6,columnspacing=1.1,frameon=False)
    fig.text(.09,.015,"Bars: hatched = 10 dBm, solid = 20 dBm; 11 fixed contexts.",fontsize=8.5)
    save(fig,out,"Fig_B_feasibility")
    return same

def plot_c(data,out):
    sweeps=rows(data/"sweep_summary.csv")
    gains=rows(data/"relative_gains.csv")
    axes=["speed","window","offset"]
    labels={"speed":"Speed (km/h)","window":"Data window (ms)","offset":"Lateral offset (m)"}
    titles={"speed":"Speed","window":"Data window","offset":"Road geometry"}
    fig,ax=plt.subplots(2,3,figsize=(7,4.3))
    fig.subplots_adjust(left=.12,right=.985,bottom=.14,top=.86,hspace=.64,wspace=.62)
    for j,axis in enumerate(axes):
        for power in (10,20):
            for method in ("TC-WRAC","B-WRAC"):
                sub=sorted([r for r in sweeps if r["axis"]==axis and r["power_dbm"]==power
                            and r["method"]==method],key=lambda r:r["axis_value"])
                x=[r["axis_value"] for r in sub]
                ax[0,j].plot(x,[r["goodput_mbps"] for r in sub],**line_style(method,power))
                ax[0,j].fill_between(x,[r["goodput_ci_low_mbps"] for r in sub],
                                    [r["goodput_ci_high_mbps"] for r in sub],
                                    color=COLORS[method],alpha=.12)
            sub=sorted([r for r in gains if r["axis"]==axis and r["power_dbm"]==power],
                       key=lambda r:r["axis_value"])
            x=np.array([r["axis_value"] for r in sub])
            y=np.array([r["relative_gain_pct"] for r in sub])
            lo=np.array([r["gain_ci_low_pct"] for r in sub])
            hi=np.array([r["gain_ci_high_pct"] for r in sub])
            assert all(r["same_risk_evidence"] for r in sub)
            ax[1,j].errorbar(x,y,yerr=[y-lo,hi-y],color="#176b9c" if power==10 else "#368a61",
                             marker="o" if power==10 else "s",ls="--" if power==10 else "-",
                             capsize=2,label=f"{power} dBm")
        vals=sorted(set(r["axis_value"] for r in gains if r["axis"]==axis))
        if axis=="offset":
            # All five data points remain plotted; avoid crowding 35 and 40 labels.
            vals=[35,60,80,100]
        for a in ax[:,j]:
            a.set_xticks(vals,[f"{v:g}" for v in vals])
            a.set_xlabel(labels[axis])
            a.grid(axis="y",alpha=.22)
        ax[0,j].set_title(f"({chr(97+j)}) {titles[axis]}")
        ax[1,j].set_title(f"({chr(100+j)}) Relative gain")
        ax[0,j].set_ylabel("Mean window\ngoodput (Mbit/s)")
        ax[1,j].set_ylabel("TC over B (%)")
        ax[1,j].axhline(0,color="black",ls=":",lw=1)
        ax[1,j].set_ylim(bottom=-.4)
    ax[1,0].legend(loc="lower left",frameon=False,handlelength=1.4)
    handles=[Line2D([],[],**line_style(m,p),label=f"{SHORT[m]}, {p} dBm")
             for p in (10,20) for m in ("TC-WRAC","B-WRAC")]
    fig.legend(handles=handles,loc="upper center",bbox_to_anchor=(.52,.995),ncol=4,
               handlelength=1.6,columnspacing=1.1,frameon=False)
    fig.text(.085,.015,"Intervals: pointwise 95%, conditional on the calibrated policies.",fontsize=8.5)
    save(fig,out,"Fig_C_throughput")

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("--data-dir",type=Path,default=HERE/"data")
    parser.add_argument("--output",type=Path,default=HERE/"figures")
    args=parser.parse_args()
    style()
    paths=[p for p in args.data_dir.rglob("*") if p.is_file()]
    hashes={str(p.relative_to(args.data_dir)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
    plot_a(args.data_dir,args.output)
    same=plot_b(args.data_dir,args.output)
    plot_c(args.data_dir,args.output)
    assert hashes=={str(p.relative_to(args.data_dir)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
    (args.output/"figure_metadata.json").write_text(json.dumps(dict(
        source_data_sha256=hashes,source_data_changed=False,simulations_run=False,
        figure_width_inches=7,selected_m_identical_at_two_powers=same,
        risk_scope="existing 1100-item family; not recalibrated here",
        interval_scope="existing pointwise 95% intervals"),ensure_ascii=False,indent=2))
    print("3 figures saved as PDF/SVG/PNG; source hashes unchanged.")
    print("Selected m at both powers:",same)

if __name__=="__main__":
    main()
