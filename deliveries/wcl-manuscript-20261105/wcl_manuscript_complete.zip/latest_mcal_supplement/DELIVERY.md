# 交付文件与复核方式

本轮研究目录为 `astra_MCal_20261105`。正式参数在 `protocol.json` 中冻结，TC/B 对照政策来自此前 Astra A–C 的 22 个基准条件。本轮没有修改原 Astra 源码、先前 A–C 结果或现有稿件。

## 两个压缩包

1. **强校准对比_图表与报告.zip**：中文报告、PNG/PDF/SVG 图件、汇总 CSV、候选与选择记录、协议和审查说明。用于阅读、作图和查看结论；不含逐窗口缓存，不能直接作为恢复运行目录。
2. **强校准对比_完整源码与原始统计.zip**：完整研究源码、冻结输入、Astra 原源码副本、CAL/CERT/TEST 逐窗口统计缓存、选优与测试锁定记录、校验结果及全部报告图表。该包保留恢复核验所需的全部文件。

两个包均含 `PACKAGE_MANIFEST_SHA256.json`，列出所有其他文件的 SHA256。打包脚本还逐项核对解压后字节与磁盘源文件，并检查 ZIP CRC。工作区的 `delivery/delivery_manifest.json` 给出两个包的 SHA256 与字节数。

## 阅读入口

- `results/强校准基线对比报告.docx` 或同名 `.md`：完整统计口径、结果及研究含义。
- `results/figures/Fig_MCal_mean_and_gain.png`：两功率平均 goodput 与 TC 相对三种基线的收益。
- `results/figures/Fig_MCal_context_goodput_risk.png`：全部 11 个位置的 goodput 和独立 TEST 风险上界。
- `results/figures/Fig_MCal_margin_factors.png`：TC、Bonferroni、M-Local、M-Global 的冻结裕量。
- `results/aggregate_results.csv`、`results/comparisons.csv`：可直接复用的数字。
- `results/condition_results.csv`、`results/candidate_results.csv`、`results/selection.json`：逐条件结果及预先锁定的选择。

## 复核或重画

完整包使用 Python 3.12。依赖包括 NumPy、SciPy、Matplotlib、python-docx 和 pytest；实际版本见 `results/registration.json`。可参考 `astra_source/requirements.txt` 安装核心依赖，另外安装 `python-docx` 以生成 Word 报告。

从解压后的研究根目录执行：

```bash
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 python -m pytest -q test_mcal_core.py
python report_mcal.py
```

第一条核验批量评估与原 Astra 真链路计算的一致性；第二条只重算统计与图表，不生成新的 Monte Carlo 样本。完整包中可运行 `python run_study.py --workers 4` 检查输入/选择/缓存哈希并恢复已有结果。若要从零复现，应复制到一个新的研究目录，并先将该副本的整个 `results` 目录移到别处保存；保留所有源码、协议、设计和冻结政策输入。避免仅删除部分缓存，因为恢复检查会据此报错。

原始缓存 `results/cases/<case_id>/CAL.npz`、`CERT.npz`、`TEST.npz` 保存逐窗口成功/中断与域内状态；TEST 还保存最小 SNR。它们不是完整车辆轨迹日志。轨迹可由冻结的种子、阶段编号、批大小与原运动模型重建，对应摘要哈希见每个 case 的流记录。

## 解释结果时的边界

主风险目标为每个已服务固定预测上下文 0.9%，不能只对位置混合均值认证。goodput 对所有 11 个位置等权，包括失败与拒绝的零值。性能区间条件于这次冻结政策，不包含重新校准的波动。

M 方法每条件使用 50,000 条完整轨迹进行 CAL 和额外 50,000 条独立轨迹进行 CERT；TC 沿用此前 50,000 个高斯最大值样本的校准。当前比较统一业务规则和风险目标，没有建立等离线样本成本、实时计算或模型失配下的优劣。数据窗口外的 2 ms 是假设开销。
