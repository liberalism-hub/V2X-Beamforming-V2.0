# Astra 强校准裕量对照

本目录是独立的新研究，不覆盖既有 A–C 或稿件。当前结论：在固定的 22 个基准条件中，TC 相对 Bonferroni 保持正收益；两种通过逐条件独立风险认证的裕量基线 M-Local/M-Global 均取得更高的平均 goodput。

先读：

- `results/强校准基线对比报告.docx` 或同名 `.md`：详细结果与统计解释。
- `结论与稿件影响.md`：这次证据如何改变论文定位。
- `results/figures/Fig_MCal_mean_and_gain.png`：两档功率的均值和 TC 相对三基线的收益。
- `results/figures/Fig_MCal_context_goodput_risk.png`：11 位置的 goodput 与逐位置风险界。
- `PROTOCOL.md`、`protocol.json`：正式采样前固定的协议。
- `review/protocol_review.md`：独立协议和来源审查。
- `results/validation.json`、`results/reporting_validation.json`：原始证据与报告审计。

## 复核现有结果

Python 3.11+，依赖 `numpy scipy matplotlib python-docx`。当前研究使用 Python/依赖版本见 `results/registration.json`。无需网络服务或外部凭据。

```bash
export OPENBLAS_NUM_THREADS=1
export OMP_NUM_THREADS=1
export MKL_NUM_THREADS=1
export MPLCONFIGDIR=/tmp/astra_mcal_mpl
python -m unittest test_mcal_core -v
python validate_study.py
python report_mcal.py
```

`validate_study.py` 独立重算选择、计数、置信界及部分原始轨迹回放；不会重选政策或覆盖正式样本。`report_mcal.py` 从冻结汇总重建图表和统计报告。

## 重新运行

本目录附完整原始缓存时，`python run_study.py --workers 4` 会验证注册/策略/缓存哈希并恢复现有结果，不重复采样。完整独立复现请复制整个目录到新位置，将副本中的 `results` 目录改名存档后运行：

```bash
python run_study.py --smoke
python run_study.py --workers 4
python validate_study.py
python report_mcal.py
```

各阶段 RNG 由根种子、稳定条件键和阶段号决定，批量大小属于协议。不同系统或数学库的浮点计算可能有细微差异；原环境与软件版本已记录。重新运行时政策性能推断仍限于指定模型、固定预测上下文和一次校准选择。

如果要改变参数、候选网格、样本数或选择规则，应建立另一个明确标识的新实验，不能修改本轮冻结证据。

## 文件职责

- `astra_source/`：上传 Astra 源的未修改副本，原始 manifest 中 117 文件保留。
- `frozen_policies.json`：来自旧 A–C 的 22 条件 TC/B 决策及分位数；`frozen_inputs_manifest.json` 记录来源哈希。
- `mcal_core.py`：每个裕量的完整候选搜索与同真值配对评估；不显式读取 R。
- `run_study.py`：独立 CAL/CERT，局部/全局裕量选择，先锁定后 TEST。
- `results/cases/*/CAL.npz`、`CERT.npz`：全部 25 候选的成功、失败和域有效性原始数组。
- `results/cases/*/TEST.npz`：四方法配对测试指标，包括真实最小 SNR。
- `results/selection_lock.json`：全部选择和拟合记录的锁定哈希与时间。
- `report_mcal.py`：分层同时 CP 区间传播、图表和中文报告。
- `validate_study.py`：独立审计；`package_mcal.py`：交付归档。

2 ms 开销仍是离线通信评价的假设，本轮没有建立在线实现时限保证。M 使用额外的完整轨迹校准与认证数据；此次不是等样本或等计算成本比较。
