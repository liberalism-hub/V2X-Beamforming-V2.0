# LaTeX编译环境诊断与可复用配置

## 已验证路线

使用现有XeLaTeX引擎，并在工作区局部提供缺失包。最小中文IEEEtran测试已成功生成：

- build_tools/smoke.tex
- build_tools/smoke.pdf（1页）
- build_tools/smoke.log、smoke.stdout.log

测试覆盖IEEE双栏类、ctex/Fandol中文、TeX Gyre Termes拉丁字体、数学、algorithm/algpseudocode、hyperref。

## 原环境缺失

系统已有TeX Live 2024基础、latex-recommended、latex-extra和XeTeX，但缺少：

- IEEEtran类（texlive-publishers）；
- ctex、xeCJK、Fandol中文字体（texlive-lang-chinese/cjk）；
- algorithm及algorithmicx（texlive-science）；
- TeX Gyre Termes字体（fonts-texgyre）。

初查kpsewhich未返回xelatex格式，不代表格式不存在；实际/var/lib/texmf/web2c/xetex/xelatex.fmt已存在，未重新生成。

## 局部依赖来源

遵守环境的继承代理、TLS与允许的Debian包源，从deb.debian.org下载：

- texlive-lang-chinese_2024.20250309-1_all.deb
- texlive-lang-cjk_2024.20250309-1_all.deb
- texlive-publishers_2024.20250309-2_all.deb
- texlive-science_2024.20250309-2_all.deb
- fonts-texgyre_20180621-6_all.deb

所有包使用dpkg-deb -x解压到build_tools/tex_deps，没有安装到系统目录，没有执行包维护脚本。下载URL、字节数和SHA256记录于build_tools/downloads/download_manifest.json。

## 编译命令

在修改稿所在目录执行：

    source /workspace/manuscripts/astra_alignment_20261105/build_tools/tex_env.sh
    xelatex -no-shell-escape -halt-on-error -interaction=nonstopmode -output-directory=build paper.tex
    xelatex -no-shell-escape -halt-on-error -interaction=nonstopmode -output-directory=build paper.tex

先创建输出build目录；paper.tex替换为实际文件名。重复两次用于稳定交叉引用；如仍有rerun提示，可再运行一次。本文档中的命令是本工作区配置，不要求把整个本地依赖树随论文交付；正常完整TeX Live/Overleaf应使用自带的相应类、包与字体。

tex_env.sh只设置TeX局部树、TeX缓存与局部fontconfig。未改HOME、未覆盖系统配置、未更改网络策略。局部fontconfig优先使用OpenType/TrueType字体，避免原系统fontconfig将Nimbus Roman解析为xdvipdfmx不能嵌入的Type1文件。

## 已知非致命警告

IEEEtran在XeLaTeX/ctex组合下会出现TU/ptm初始字体或中文smallcaps的替代提示；最小文档中最终正文拉丁字体为TeX Gyre Termes，中文为Fandol，PDF正常生成，未观察到missing-character。中文小型大写没有独立字形，按正常中文形状代替。

## 正式修改稿最终编译核验

正式源为revised/manuscript_revised.tex，表格为tables_results.tex，三张主图已随稿提供。对主进程冻结后的内容连续运行两遍XeLaTeX，均禁用shell escape。最终PDF已复制到revised/manuscript_revised.pdf。

- 页数：7页，中文研究工作稿，尚未压缩为WCL投稿篇幅。
- 致命错误、未定义引用/文献、重复标签、缺图或missing-character：均为0。
- Overfull/Underfull hbox：均为0。
- 字体警告：6条，包含4条IEEEtran初始化TU/ptm替代、1条中文smallcaps替代及1条汇总提示；实际PDF字体已嵌入，未发现缺字。
- pdftotext抽取34909字符，无Unicode替代字符。
- 已渲染并查看第1、4、7页，正文、公式、图注和图面无裁切或文字重叠。末页为单独的图3浮动页，保留标准布局，未通过缩小字体压页。

仅作两处必要排版修改：把成功事件中的中文域条件移到下一公式行，消除2.15pt溢出；将高斯采样段落改写为等义的“独立生成S个服从该分布的高斯向量，并分别记录最大绝对分量”，消除underfull。

最终源SHA256为cf817f8ef34ab8a02a3eab888ce3e9c6d6d3006bb629576fdde2d4782f3e598e；表SHA256为7857c1d5709946773d2a80a7517531b0c80f01ba13341a1ccfb7890855212750。编译前后核对一致。最终PDF SHA256为6e08abd256fe8e6a45e6340604e483e4fcb01cb7719200eae68698822f1ab7e2。

机器可读核验记录位于revised/build/compilation_validation.json。渲染图位于build_tools/rendered/page_1.png、page_4.png、page_7.png。
